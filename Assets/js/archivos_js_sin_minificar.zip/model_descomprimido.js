autosize($('#baseInstructions'))
autosize($('#contentInstructions'))
autosize($('#imageInstructions'))

function createPreviewforImage(btn) {
    $("#row-multimedia").empty()
    let numberFileImage = btn.val()
    let counterFileImage = 1
    while (counterFileImage <= numberFileImage) {
        let label = $('<label>', { 'class': 'form-control-files btn btn-enviar mb-0 mt-3', html: 'Picture ' + counterFileImage })
        let icon = $('<i>', { style: 'margin-left:1em', 'class': 'fas fa-upload', 'aria-hidden': 'true' })
        let input = $('<input>', { style: 'display: none', type: 'file', id: 'btnImage_' + counterFileImage, name: 'btnImage_' + counterFileImage, accept: "image/jpeg, image/png, image/jpg" })
        let msg = $("<div>", { 'class': 'msg msg_' + input.attr('id') })
        let preview = $('<div>', { id: 'preview_' + counterFileImage, 'class': 'minis img-thumbnail mt-3' })
        $("#row-multimedia").append(label.append(input, icon), msg, preview)
        $(input).change(function () {
            chargePreviewforImage(preview, input)
        })
        let labelNumberPicture = $('<label>', { 'class': 'form-label mt-3', html: 'Number of content fields for Picture ' + counterFileImage + ':' })
        let inputNumberPicture = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtNumberPicture_' + counterFileImage, name: 'txtNumberPicture_' + counterFileImage, placeholder: 'Enter a number of content fields', maxLength: 2, required: true })
        let messageNumberPicture = $('<div>', { 'class': 'msg msg_' + inputNumberPicture.attr('id') })
        $("#row-multimedia").append(labelNumberPicture, inputNumberPicture, messageNumberPicture)
        const rowFieldsPicture = $('<div>', { id: 'content_picture_' + counterFileImage, 'class': 'row' })
        $("#row-multimedia").append(rowFieldsPicture)
        $(inputNumberPicture).keyup(function () {
            let numberFieldsPicture = $(this).val()
            rowFieldsPicture.empty()
            let positionPicture = inputNumberPicture.attr('id').split('_')
            let counterFieldsPicture = 1
            while (counterFieldsPicture <= numberFieldsPicture) {
                let containerContentPicture = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' })
                let labelContentPicture = $('<label>', { 'class': 'form-label', html: 'Content fields:' })
                let inputContentPicture = $('<textarea>', { id: "contentPicture_" + positionPicture[1] + "_" + counterFieldsPicture, name: "contentPicture_" + positionPicture[1] + "_" + counterFieldsPicture, 'class': 'form-control', style: 'height:38px', placeholder: 'Enter a content fields', maxLength: 500, required: true })
                let messageContentPicture = $("<div>", { 'class': 'msg msg_' + inputContentPicture.attr('id') })
                rowFieldsPicture.append(containerContentPicture.append(labelContentPicture, inputContentPicture, messageContentPicture))
                autosize(inputContentPicture)
                counterFieldsPicture++
            }
        })
        counterFileImage++
    }
}

function chargePreviewforImage(preview, btn) {
    preview.empty()
    let kilobyte = (parseInt(btn.prop('files')[0].size) / 1024)
    if (btn.prop('files').length !== 0 && kilobyte < 2048) {
        let reader = new FileReader()
        reader.readAsDataURL(btn.prop('files')[0])
        reader.onload = function () {
            let picture = $('<picture>')
            let image = $('<img>', { 'class': 'minis img-' + btn.attr('id'), src: reader.result, alt: btn.prop('files')[0].name })
            preview.append(picture.append(image))
        }
        $(".msg_" + btn.attr('name')).removeClass("invalid")
        $(".msg_" + btn.attr('name')).empty()
    } else {
        message("error", "the image is too large (maximum 2MB)", "#CC1E1E")
        btn.val('')
    }
}

function chargeVideo(btn) {
    $("#row-multimedia").empty()
    let kiloByte = (parseInt(btn.prop('files')[0].size) / 1024)
    if (btn.prop('files').length !== 0 && kiloByte < 5242880) {
        let reader = new FileReader()
        reader.readAsDataURL(btn.prop('files')[0])
        reader.onload = function () {
            let playerFieldVideo = $('<video>', { id: 'video-tag', 'class': 'embed-responsive embed-responsive-16by9 mt-3', controls: true, preload: 'metada' })
            let sourceFieldVideo = $('<source>', { id: 'video-source', src: reader.result })
            $("#row-multimedia").append(playerFieldVideo.append(sourceFieldVideo))
            let labelNumberVideo = $('<label>', { 'class': 'form-label mt-3', html: 'Number of content fields for the video:' })
            let inputNumberVideo = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtNumberVideo', name: 'txtNumberVideo', placeholder: 'Enter a number of content fields', maxLength: 2, required: true })
            let messageNumberVideo = $('<div>', { 'class': 'msg msg_' + inputNumberVideo.attr('id') })
            $("#row-multimedia").append(labelNumberVideo, inputNumberVideo, messageNumberVideo)
            let containerFieldsVideo = $('<div>', { 'class': 'col-12' })
            const rowFieldsVideo = $('<div>', { id: 'content_fieldsvideo', 'class': 'row' })
            $("#row-multimedia").after(containerFieldsVideo.append(rowFieldsVideo))
            $(inputNumberVideo).keyup(function () {
                let numberFieldsVideo = $(this).val()
                rowFieldsVideo.empty()
                let counterFieldsVideo = 1
                while (counterFieldsVideo <= numberFieldsVideo) {
                    let containerContentVideo = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' })
                    let labelContentVideo = $('<label>', { 'class': 'form-label', html: 'Content fields:' })
                    let inputContentVideo = $('<textarea>', { id: "contentVideo_" + counterFieldsVideo, name: "contentVideo_" + counterFieldsVideo, 'class': 'form-control', style: 'height:38px', placeholder: 'Enter a content fields', maxLength: 500, required: true })
                    let messageContentVideo = $("<div>", { 'class': 'msg msg_' + inputContentVideo.attr('id') })
                    rowFieldsVideo.append(containerContentVideo.append(labelContentVideo, inputContentVideo, messageContentVideo))
                    autosize(inputContentVideo)
                    counterFieldsVideo++
                }
            })
        }
        $(".msg_" + btn.attr('name')).removeClass("invalid")
        $(".msg_" + btn.attr('name')).empty()
    } else {
        message("error", "the video is too large (maximum 5GB)", "#CC1E1E")
        btn.val('')
    }
}

$('#cboSection').change(function () {
    $('#cboSubsection').empty()
    $.ajax({
        type: 'POST',
        url: $('#ruta').val(),
        data: { cboSection: $(this).val() },
        success: function (data) {
            $('#cboSubsection').append(data)
        }
    })
})

$('#switchmls').on("change", function () {
    $('.switchmls').empty()
    if ($(this).prop('checked')) {
        $('.switchmls').text('Active')
    } else {
        $('.switchmls').text('Inactive')
    }
})

$('#switchpicture').on("change", function () {
    $('.switchpicture').empty()
    if ($(this).prop('checked')) {
        $('.switchpicture').text('Active')
    } else {
        $('.switchpicture').text('Inactive')
    }
})

$("#txtBase").keyup(function () {
    let numberBaseFields = $(this).val()
    $("#row-base").empty()
    let counterBaseFields = 1
    while (counterBaseFields <= numberBaseFields) {
        let containerBaseField = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' })
        let labelBaseField = $('<label>', { 'class': 'form-label', html: 'Base fields:' })
        let textBaseField = $('<input>', { type: 'text', id: 'base_' + counterBaseFields, name: 'base_' + counterBaseFields, 'class': 'form-control', placeholder: 'Enter a name of base fields', maxLength: 50, required: true })
        let instruccionsBaseField = $("<div>", { 'class': 'msg msg_' + textBaseField.attr('id') })
        let containerValidateRequired = $("<div>", { 'class': 'custom-control custom-radio custom-control-inline' })
        let radioValidateRequired = $('<input>', { type: 'radio', id: 'required_' + counterBaseFields, name: 'validate_' + counterBaseFields, 'class': 'custom-control-input', val: 1 })
        let labelValidateRequired = $('<label>', { for: 'required_' + counterBaseFields, 'class': 'custom-control-label', html: 'Required' })
        let containerValidateNorequired = $("<div>", { 'class': 'custom-control custom-radio custom-control-inline' })
        let radioValidateNorequired = $('<input>', { type: 'radio', id: 'norequired_' + counterBaseFields, name: 'validate_' + counterBaseFields, 'class': 'custom-control-input', val: 0, checked: true })
        let labelValidateNorequired = $('<label>', { for: 'norequired_' + counterBaseFields, 'class': 'custom-control-label', html: 'No required' })
        $("#row-base").append(containerBaseField.append(labelBaseField, textBaseField, instruccionsBaseField, containerValidateRequired.append(radioValidateRequired, labelValidateRequired), containerValidateNorequired.append(radioValidateNorequired, labelValidateNorequired)))
        counterBaseFields++
    }
})

$('#cboMultimedia').change(function () {
    $("#row-multimedia").empty()
    $('#link,#video,#quantity').remove()
    $('#content_fieldsvideo,#content_fieldslink').empty()
    const iconUploadFile = $('<i>', { style: 'margin-left:1em', 'class': 'fas fa-upload', 'aria-hidden': 'true' })
    if ($(this).val() == 'video') {
        let containerFileVideo = $('<div>', { id: 'video', 'class': 'col-12 mt-3' })
        let labelFileVideo = $('<label>', { 'class': 'form-control-files btn btn-enviar mb-0', html: 'Video' })
        let inputFileVideo = $('<input>', { style: 'display:none', type: 'file', id: 'btnVideo', name: 'btnVideo', accept: 'video/*' })
        let messageFileVideo = $('<div>', { 'class': 'msg msg_' + inputFileVideo.attr('id') })
        $('#type-multimedia').after(containerFileVideo.append(labelFileVideo.append(inputFileVideo, iconUploadFile), messageFileVideo))
        $(inputFileVideo).change(function () {
            chargeVideo($(this))
        })
    } else if ($(this).val() == 'link') {
        let containerLinkField = $('<div>', { id: 'link', 'class': 'col-12 mt-3' })
        let labelLinkField = $('<label>', { 'class': 'form - label', html: 'Link:' })
        let inputLinkField = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtLink', name: 'txtLink', placeholder: 'Enter the link', maxLength: 100, required: true })
        let messageLinkField = $('<div>', { 'class': 'msg msg_' + inputLinkField.attr('id') })
        $('#type-multimedia').after(containerLinkField.append(labelLinkField, inputLinkField, messageLinkField))
        $(inputLinkField).keyup(function () {
            $("#row-multimedia").empty()
            let url
            let regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|shorts\/|\&v=)([^#\&\?]*).*/
            let match = $(this).val().match(regExp)
            if (match && match[2].length == 11) {
                url = 'https://www.youtube.com/embed/' + match[2]
                let containerLink = $('<div>', { 'class': 'embed-responsive embed-responsive-16by9 mt-3' })
                let iframeLink = $('<iframe>', { class: 'embed-responsive-item', src: url, allowfullscreen: true })
                $("#row-multimedia").append(containerLink.append(iframeLink))
                if (!window.location.pathname.includes('Uploaddata')) {
                    let labelNumberLink = $('<label>', { 'class': 'form-label mt-3', html: 'Number of content fields for the video:' })
                    let inputNumberLink = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtNumberLink', name: 'txtNumberLink', placeholder: 'Enter a number of content fields', maxLength: 2, required: true })
                    let messageNumberLink = $('<div>', { 'class': 'msg msg_' + inputNumberLink.attr('id') })
                    $("#row-multimedia").append(labelNumberLink, inputNumberLink, messageNumberLink)
                    let containerFieldsLink = $('<div>', { 'class': 'col-12' })
                    const rowFieldsLink = $('<div>', { id: 'content_fieldslink', 'class': 'row' })
                    $("#row-multimedia").after(containerFieldsLink.append(rowFieldsLink))
                    $(inputNumberLink).keyup(function () {
                        let numberFieldsLink = $(this).val()
                        rowFieldsLink.empty()
                        let counterFieldsLink = 1
                        while (counterFieldsLink <= numberFieldsLink) {
                            let containerContentLink = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' })
                            let labelContentLink = $('<label>', { 'class': 'form-label', html: 'Content fields:' })
                            let inputContentLink = $('<textarea>', { id: "contentLink_" + counterFieldsLink, name: "contentLink_" + counterFieldsLink, 'class': 'form-control', style: 'height:38px', placeholder: 'Enter a content fields', maxLength: 500, required: true })
                            let instruccionsContentLink = $("<div>", { 'class': 'msg msg_' + inputContentLink.attr('id') })
                            rowFieldsLink.append(containerContentLink.append(labelContentLink, inputContentLink, instruccionsContentLink))
                            autosize(inputContentLink)
                            counterFieldsLink++
                        }
                    })
                }
            }
        })
    } else {
        let containerQuantityField = $('<div>', { id: 'quantity', 'class': 'col-12 mt-3' })
        let labelQuantityField = $('<label>', { 'class': 'form - label', html: 'Quantity of multimedia:' })
        let inputQuantityField = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtMultimedia', name: 'txtMultimedia', placeholder: 'Enter a number amount of media content', maxLength: 50, required: true })
        let messageQuantityField = $('<div>', { 'class': 'msg msg' + inputQuantityField.attr('id') })
        $('#type-multimedia').after(containerQuantityField.append(labelQuantityField, inputQuantityField, messageQuantityField))
        $(inputQuantityField).keyup(function () {
            createPreviewforImage($(this))
        })
    }
})

$('#txtMultimedia').keyup(function () {
    createPreviewforImage($(this))
})

$("#txtNumber-size").keyup(function () {
    let numberSizeFields = $(this).val()
    $("#row-sizes").empty()
    let counterSizeFields = 1
    while (counterSizeFields <= numberSizeFields) {
        let containerDescriptionFields = $('<div>', { 'class': 'col-12 col-md-7 col-xl-7 mt-3' })
        let labelDescriptionFields = $('<label>', { 'class': 'form-label', html: 'Description:' })
        let inputDescriptionFields = $('<input>', { type: 'text', id: 'txtSize_' + counterSizeFields, name: 'txtSize_' + counterSizeFields, 'class': 'form-control', placeholder: 'Enter the description', maxLength: 50, required: true })
        let messageDescriptionFields = $("<div>", { 'class': 'msg msg_' + inputDescriptionFields.attr('id') })
        $("#row-sizes").append(containerDescriptionFields.append(labelDescriptionFields, inputDescriptionFields, messageDescriptionFields))
        let containerPriceFields = $('<div>', { 'class': 'col-12 col-md-5 col-xl-5 mt-3' })
        let labelPriceFields = $('<label>', { 'class': 'form-label', html: 'Price (The price can be 0 if the item is free):' })
        let inputPriceFields = $('<input>', { type: 'text', id: 'txtPrice_' + counterSizeFields, name: 'txtPrice_' + counterSizeFields, 'class': 'form-control', placeholder: 'Enter the price', maxLength: 15, required: true })
        let messagePriceFields = $("<div>", { 'class': 'msg msg_' + inputPriceFields.attr('id') })
        $("#row-sizes").append(containerPriceFields.append(labelPriceFields, inputPriceFields, messagePriceFields))
        counterSizeFields++
    }
})

function validateModel(form) {
    let validateForm = true
    let inputsForm = $("#" + form.attr('id') + " :input,textarea")
    inputsForm.each(function () {
        let messageError = ".msg_" + $(this).attr("id")
        switch (true) {
            case $(this)[0].localName === "textarea" && $(this).attr("id").includes("Instructions") && $(this).val() === "":
                $(this).addClass("invalid")
                $(messageError).html("The instruction is required")
                validateForm = false
                break
            case $(this)[0].localName === "textarea" && $(this).val() === "":
                $(this).addClass("invalid")
                $(messageError).html("The content is required")
                validateForm = false
                break
            case $(this).attr("type") == "text" && $(this).val() === '':
                $(this).addClass("invalid")
                $(messageError).html("The information is required")
                validateForm = false
                break
            case $(this).attr("type") == "file" && $(this).get(0).files.length === 0:
                $(this).addClass("invalid")
                $(messageError).html("The file is required")
                validateForm = false
                break
        }
        $(this).keyup(function () {
            $(this).removeClass("invalid")
            $(messageError).empty()
        })
    })
    return validateForm
}

$("#newModel").bind("submit", function () {
    if (validateModel($(this))) {
        $.ajax({
            type: $(this).attr("method"),
            url: $(this).attr("action"),
            data: new FormData(this),
            contentType: false,
            processData: false,
            dataType: "json",
            success: function (data) {
                if (data['message'] != 'Successfully saved') {
                    message("error", data['message'], "#CC1E1E")
                } else {
                    message("success", data['message'], "#4CC522")
                    $("#newModel")[0].reset()
                    $('#quantity,#video,#link').remove()
                    $("#row-base,#row-multimedia,#row-content,#row-sizes").empty()
                    let div = $('<div>', { id: 'quantity', 'class': 'col-12 mt-3' })
                    let label = $('<label>', { 'class': 'form - label', html: 'Quantity of multimedia:' })
                    let input = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtMultimedia', name: 'txtMultimedia', placeholder: 'Enter a number amount of media content', maxLength: 50, required: true })
                    let msg = $('<div>', { 'class': 'msg msg_txtMultimedia' })
                    $(input).keyup(function () {
                        createPreviewforImage($(input))
                    })
                    $('#type-multimedia').after(div.append(label, input, msg))
                    setTimeout(() => { window.location.href = data['route'] }, 1500)
                }
            }
        })
    }
    return false
})

$(".delete").on('click', function () {
    $("#model").val($(this).val())
})

$("#deleteModel").bind("submit", function (e) {
    e.preventDefault()
    $.ajax({
        type: $(this).attr("method"),
        url: $(this).attr("action"),
        data: new FormData(this),
        contentType: false,
        processData: false,
        success: function (data) {
            if (data != "Successfully removed") {
                message("error", data, "#CC1E1E")
            } else {
                $('#deleteModal').modal('hide')
                message("success", data, "#4CC522")
                setTimeout(() => { location.reload() }, 1500)
            }
        },
    })
})

