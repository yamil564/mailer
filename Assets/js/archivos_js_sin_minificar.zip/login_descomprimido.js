function validaForm() {
  let bool = true;
  let inputs = $("input");
  inputs.each(function () {
    let mensaje = ".msg_" + $(this).attr("id");
    if ($(this).val() === "") {
      $(this).addClass("invalid");
      $(mensaje).html("The field is required");
      bool = false;
    }
    $(this).keyup(function () {
      $(this).removeClass("invalid");
      $(mensaje).empty();
    });
  });
  return bool;
}

function message(icon, bool, title, background) {
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 1500,
    timerProgressBar: bool,
  });
  Toast.fire({
    icon: icon,
    iconColor: "#fff",
    title: title,
    background: background,
  });
}

$("#enviar").bind("submit", function () {
  if (validaForm()) {
    $.ajax({
      type: $(this).attr("method"),
      url: $(this).attr("action"),
      data: $(this).serialize(),
      dataType: "json",
      success: function (data) {
        if (data[1] === "Signed in successfully") {
          message("success", true, data[1], "#4CC522");
          setTimeout(() => { window.location.href = data[0]; }, 1500);
        } else {
          message("error", false, data[1], "#CC1E1E");
        }
      },
    });
  }
  return false;
});
