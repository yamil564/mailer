$(document).ready(function () {
  const rowBaseFields = $("#row-base");
  const containerTypeMultimedia = $('#type-multimedia');
  const rowContainerMultimedia = $("#row-multimedia");
  const rowContainerFieldsFront = $("#content_fieldsFront");
  const rowContainerFieldsBack = $("#content_fieldsBack");
  const rowContainerSize = $("#row-sizes");

  autosize($('#baseInstructions'));
  autosize($('#contentInstructions'));
  autosize($('#imageInstructions'));

  function chargeVideo(preview, btn, route) {
    preview.empty();
    let kiloByte = parseInt(btn.prop('files')[0].size) / 1024;
    if (btn.prop('files').length !== 0 && kiloByte < 5242880) {
      let reader = new FileReader();
      reader.readAsDataURL(btn.prop('files')[0]);
      reader.onload = function () {
        let playerFieldVideo = $('<video>', { id: 'video-tag', 'class': 'embed-responsive embed-responsive-16by9 mt-3', controls: true, preload: 'metada' });
        let sourceFieldVideo = $('<source>', { id: 'video-source', src: reader.result });
        preview.append(playerFieldVideo.append(sourceFieldVideo));
        if (!route.includes('Uploaddata')) {
          let labelNumberVideo = $('<label>', { 'class': 'form-label mt-3', html: 'Number of content fields for the video:' });
          let inputNumberVideo = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtNumberVideo', name: 'txtNumberVideo', placeholder: 'Enter a number of content fields', maxLength: 2, required: true });
          let messageNumberVideo = $('<div>', { 'class': 'msg msg_' + inputNumberVideo.attr('id') });
          rowContainerMultimedia.append(labelNumberVideo, inputNumberVideo, messageNumberVideo);
          let containerFieldsVideo = $('<div>', { 'class': 'col-12' });
          const rowFieldsVideo = $('<div>', { id: 'content_fieldsvideo', 'class': 'row' });
          rowContainerMultimedia.after(containerFieldsVideo.append(rowFieldsVideo));
          $(inputNumberVideo).keyup(function () {
            let numberFieldsVideo = $(this).val();
            rowFieldsVideo.empty();
            let counterFieldsVideo = 1;
            while (counterFieldsVideo <= numberFieldsVideo) {
              let containerContentVideo = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' });
              let labelContentVideo = $('<label>', { 'class': 'form-label', html: 'Content fields:' });
              let inputContentVideo = $('<textarea>', { id: "contentVideo_" + counterFieldsVideo, name: "contentVideo_" + counterFieldsVideo, 'class': 'form-control', style: 'height:38px', placeholder: 'Enter a content fields', maxLength: 500, required: true });
              let messageContentVideo = $("<div>", { 'class': 'msg msg_' + inputContentVideo.attr('id') });
              rowFieldsVideo.append(containerContentVideo.append(labelContentVideo, inputContentVideo, messageContentVideo));
              autosize(inputContentVideo);
              counterFieldsVideo++;
            }
          });
        }
      };
      $(".msg_" + btn.attr('name')).removeClass("invalid");
      $(".msg_" + btn.attr('name')).empty();
    } else {
      message("error", "the video is too large (maximum 5GB)", "#CC1E1E");
      btn.val('');
    }
  }

  function chargePDF(preview, btn) {
    preview.empty();
    if (btn.prop('files')[0].type === "application/pdf") {
      let reader = new FileReader();
      reader.readAsDataURL(btn.prop('files')[0]);
      reader.onload = function () {
        let iframePreviewPDF = $('<iframe>', { src: reader.result, title: reader.result, style: 'width:100%; height:100%;' });
        preview.append(iframePreviewPDF);
      }
      $(".msg_" + btn.attr('name')).removeClass("invalid");
      $(".msg_" + btn.attr('name')).empty();
    } else {
      message("error", "this document is not a pdf", "#CC1E1E");
      btn.val('');
    }
  }

  function createPreviewforImage(btn, route) {
    rowContainerMultimedia.empty();
    let numberFileImage = btn.val();
    let counterFileImage = 1;
    while (counterFileImage <= numberFileImage) {
      let label = $('<label>', { 'class': 'form-control-files btn btn-enviar mb-0 mt-3', html: 'Picture ' + counterFileImage });
      let icon = $('<i>', { style: 'margin-left:1em', 'class': 'fas fa-upload', 'aria-hidden': 'true' });
      let input = $('<input>', { style: 'display: none;', type: 'file', id: 'btnImage_' + counterFileImage, name: 'btnImage_' + counterFileImage, accept: "image/jpeg, image/png, image/jpg" });
      let msg = $("<div>", { 'class': 'msg msg_' + input.attr('id') });
      let preview = $('<div>', { id: 'preview_' + counterFileImage, 'class': 'minis img-thumbnail mt-3' });
      rowContainerMultimedia.append(label.append(input, icon), msg, preview);
      $(input).change(function () {
        chargePreviewforImage(preview, input);
      });
      if (!route.includes('Uploaddata')) {
        let labelNumberPicture = $('<label>', { 'class': 'form-label mt-3', html: 'Number of content fields for Picture ' + counterFileImage + ':' });
        let inputNumberPicture = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtNumberPicture_' + counterFileImage, name: 'txtNumberPicture_' + counterFileImage, placeholder: 'Enter a number of content fields', maxLength: 2, required: true });
        let messageNumberPicture = $('<div>', { 'class': 'msg msg_' + inputNumberPicture.attr('id') });
        rowContainerMultimedia.append(labelNumberPicture, inputNumberPicture, messageNumberPicture);
        const rowFieldsPicture = $('<div>', { id: 'content_picture_' + counterFileImage, 'class': 'row' });
        rowContainerMultimedia.append(rowFieldsPicture);
        console.log(counterFileImage);
        $(inputNumberPicture).keyup(function () {
          let numberFieldsPicture = $(this).val();
          rowFieldsPicture.empty();
          let positionPicture = inputNumberPicture.attr('id').split('_');
          let counterFieldsPicture = 1;
          while (counterFieldsPicture <= numberFieldsPicture) {
            let containerContentPicture = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' });
            let labelContentPicture = $('<label>', { 'class': 'form-label', html: 'Content fields:' });
            let inputContentPicture = $('<textarea>', { id: "contentPicture_" + positionPicture[1] + "_" + counterFieldsPicture, name: "contentPicture_" + positionPicture[1] + "_" + counterFieldsPicture, 'class': 'form-control', style: 'height:38px', placeholder: 'Enter a content fields', maxLength: 500, required: true });
            let messageContentPicture = $("<div>", { 'class': 'msg msg_' + inputContentPicture.attr('id') });
            rowFieldsPicture.append(containerContentPicture.append(labelContentPicture, inputContentPicture, messageContentPicture));
            autosize(inputContentPicture);
            counterFieldsPicture++;
          }
        });
      }
      counterFileImage++;
    }
  }

  function chargePreviewforImage(preview, btn) {
    preview.empty();
    let kilobyte = parseInt(btn.prop('files')[0].size) / 1024;
    if (btn.prop('files').length !== 0 && kilobyte < 2048) {
      let reader = new FileReader();
      reader.readAsDataURL(btn.prop('files')[0]);
      reader.onload = function () {
        let picture = $('<picture>');
        let image = $('<img>', { 'class': 'minis img-' + btn.attr('id'), src: reader.result, alt: btn.prop('files')[0].name });
        preview.append(picture.append(image));
      };
      $(".msg_" + btn.attr('name')).removeClass("invalid");
      $(".msg_" + btn.attr('name')).empty();
    } else {
      message("error", "the image is too large (maximum 2MB)", "#CC1E1E");
      btn.val('');
    }
  }

  $('#cboSection').change(function () {
    $('#cboSubsection').empty();
    $.ajax({
      type: 'POST',
      url: $('#ruta').val(),
      data: { cboSection: $(this).val() },
      success: function (data) {
        $('#cboSubsection').append(data);
      }
    });
  });

  $('#switchmls').on("change", function () {
    $('.switchmls').empty();
    if ($(this).prop('checked')) {
      $('.switchmls').text('Active');
    } else {
      $('.switchmls').text('Inactive');
    }
  });

  $('#switchpicture').on("change", function () {
    $('.switchpicture').empty();
    if ($(this).prop('checked')) {
      $('.switchpicture').text('Active');
    } else {
      $('.switchpicture').text('Inactive');
    }
  });

  $("#txtBase").keyup(function () {
    let numberBaseFields = $(this).val();
    rowBaseFields.empty();
    let counterBaseFields = 1;
    while (counterBaseFields <= numberBaseFields) {
      let containerBaseField = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' });
      let labelBaseField = $('<label>', { 'class': 'form-label', html: 'Base fields:' });
      let textBaseField = $('<input>', { type: 'text', id: 'base_' + counterBaseFields, name: 'base_' + counterBaseFields, 'class': 'form-control', placeholder: 'Enter a name of base fields', maxLength: 50, required: true });
      let instruccionsBaseField = $("<div>", { 'class': 'msg msg_' + textBaseField.attr('id') });
      let containerValidateRequired = $("<div>", { 'class': 'custom-control custom-radio custom-control-inline' });
      let radioValidateRequired = $('<input>', { type: 'radio', id: 'required_' + counterBaseFields, name: 'validate_' + counterBaseFields, 'class': 'custom-control-input', val: 1 });
      let labelValidateRequired = $('<label>', { for: 'required_' + counterBaseFields, 'class': 'custom-control-label', html: 'Required' });
      let containerValidateNorequired = $("<div>", { 'class': 'custom-control custom-radio custom-control-inline' });
      let radioValidateNorequired = $('<input>', { type: 'radio', id: 'norequired_' + counterBaseFields, name: 'validate_' + counterBaseFields, 'class': 'custom-control-input', val: 0, checked: true });
      let labelValidateNorequired = $('<label>', { for: 'norequired_' + counterBaseFields, 'class': 'custom-control-label', html: 'No required' });
      rowBaseFields.append(containerBaseField.append(labelBaseField, textBaseField, instruccionsBaseField, containerValidateRequired.append(radioValidateRequired, labelValidateRequired), containerValidateNorequired.append(radioValidateNorequired, labelValidateNorequired)));
      counterBaseFields++;
    }
  });

  $('#cboMultimedia').change(function () {
    rowContainerMultimedia.empty();
    $('#content_fieldsvideo,#content_fieldslink').empty();
    $('#link,#video,#quantity').remove();
    const iconUploadFile = $('<i>', { style: 'margin-left:1em', 'class': 'fas fa-upload', 'aria-hidden': 'true' });
    if ($(this).val() == 'video') {
      let containerFileVideo = $('<div>', { id: 'video', 'class': 'col-12 mt-3' });
      let labelFileVideo = $('<label>', { 'class': 'form-control-files btn btn-enviar mb-0', html: 'Video' });
      let inputFileVideo = $('<input>', { style: 'display:none;', type: 'file', id: 'btnVideo', name: 'btnVideo', accept: 'video/*' });
      let messageFileVideo = $('<div>', { 'class': 'msg msg_' + inputFileVideo.attr('id') });
      containerTypeMultimedia.after(containerFileVideo.append(labelFileVideo.append(inputFileVideo, iconUploadFile), messageFileVideo));
      $(inputFileVideo).change(function () {
        chargeVideo(rowContainerMultimedia, $(this), window.location.pathname);
      });
    } else if ($(this).val() == 'link') {
      let containerLinkField = $('<div>', { id: 'link', 'class': 'col-12 mt-3' });
      let labelLinkField = $('<label>', { 'class': 'form - label', html: 'Link:' });
      let inputLinkField = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtLink', name: 'txtLink', placeholder: 'Enter the link', maxLength: 100, required: true });
      let messageLinkField = $('<div>', { 'class': 'msg msg_' + inputLinkField.attr('id') });
      containerTypeMultimedia.after(containerLinkField.append(labelLinkField, inputLinkField, messageLinkField));
      $(inputLinkField).keyup(function () {
        rowContainerMultimedia.empty();
        let url;
        let regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|shorts\/|\&v=)([^#\&\?]*).*/;
        let match = $(this).val().match(regExp);
        if (match && match[2].length == 11) {
          url = 'https://www.youtube.com/embed/' + match[2];
          let containerLink = $('<div>', { 'class': 'embed-responsive embed-responsive-16by9 mt-3' });
          let iframeLink = $('<iframe>', { class: 'embed-responsive-item', src: url, allowfullscreen: true });
          rowContainerMultimedia.append(containerLink.append(iframeLink));
          if (!window.location.pathname.includes('Uploaddata')) {
            let labelNumberLink = $('<label>', { 'class': 'form-label mt-3', html: 'Number of content fields for the video:' });
            let inputNumberLink = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtNumberLink', name: 'txtNumberLink', placeholder: 'Enter a number of content fields', maxLength: 2, required: true });
            let messageNumberLink = $('<div>', { 'class': 'msg msg_' + inputNumberLink.attr('id') });
            rowContainerMultimedia.append(labelNumberLink, inputNumberLink, messageNumberLink);
            let containerFieldsLink = $('<div>', { 'class': 'col-12' });
            const rowFieldsLink = $('<div>', { id: 'content_fieldslink', 'class': 'row' });
            rowContainerMultimedia.after(containerFieldsLink.append(rowFieldsLink));
            $(inputNumberLink).keyup(function () {
              let numberFieldsLink = $(this).val();
              rowFieldsLink.empty();
              let counterFieldsLink = 1;
              while (counterFieldsLink <= numberFieldsLink) {
                let containerContentLink = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' });
                let labelContentLink = $('<label>', { 'class': 'form-label', html: 'Content fields:' });
                let inputContentLink = $('<textarea>', { id: "contentLink_" + counterFieldsLink, name: "contentLink_" + counterFieldsLink, 'class': 'form-control', style: 'height:38px', placeholder: 'Enter a content fields', maxLength: 500, required: true });
                let instruccionsContentLink = $("<div>", { 'class': 'msg msg_' + inputContentLink.attr('id') });
                rowFieldsLink.append(containerContentLink.append(labelContentLink, inputContentLink, instruccionsContentLink));
                autosize(inputContentLink);
                counterFieldsLink++;
              }
            });
          }
        }
      });
    } else if ($(this).val() == 'pdf') {
      let containerFilePDF = $('<div>', { id: 'quantity', 'class': 'col-12 mt-3' });
      let labelFilePDF = $('<label>', { 'class': 'form-control-files btn btn-enviar mb-0', html: 'PDF Document' });
      let inputFilePDF = $('<input>', { style: 'display:none;', type: 'file', id: 'btnPdf', name: 'btnPdf', accept: 'application/pdf' });
      let messageFilePDF = $('<div>', { 'class': 'msg msg_' + inputFilePDF.attr('id') });
      let previewFilePDF = $('<div>', { id: 'preview_' + inputFilePDF.attr('id'), 'class': 'minis img-thumbnail mt-3' });
      containerTypeMultimedia.after(containerFilePDF.append(labelFilePDF.append(inputFilePDF, iconUploadFile), messageFilePDF, previewFilePDF));
      $(inputFilePDF).change(function () {
        chargePDF(previewFilePDF, inputFilePDF);
      });
    } else {
      let containerQuantityField = $('<div>', { id: 'quantity', 'class': 'col-12 mt-3' });
      if (!window.location.pathname.includes('Uploaddata')) {
        let labelQuantityField = $('<label>', { 'class': 'form - label', html: 'Quantity of multimedia:' });
        let inputQuantityField = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtMultimedia', name: 'txtMultimedia', placeholder: 'Enter a number amount of media content', maxLength: 50, required: true });
        let messageQuantityField = $('<div>', { 'class': 'msg msg' + inputQuantityField.attr('id') });
        containerTypeMultimedia.after(containerQuantityField.append(labelQuantityField, inputQuantityField, messageQuantityField));
        $(inputQuantityField).keyup(function () {
          createPreviewforImage($(this), window.location.pathname);
        });
      } else {
        let labelFilePicture = $('<label>', { 'class': 'form-control-files btn btn-enviar mb-0', html: 'Picture' });
        let inputFilePicture = $('<input>', { style: 'display:none;', type: 'file', id: 'btnImage', name: 'btnImage', accept: 'image/jpeg, image/png, image/jpg' });
        let messageFilePicture = $('<div>', { 'class': 'msg msg_' + inputFilePicture.attr('id') });
        let previewFilePicture = $('<div>', { id: 'preview_' + inputFilePicture.attr('id'), 'class': 'minis img-thumbnail mt-3' });
        containerTypeMultimedia.after(containerQuantityField.append(labelFilePicture.append(inputFilePicture, iconUploadFile), messageFilePicture, previewFilePicture));
        $(inputFilePicture).change(function () {
          chargePreviewforImage(preview, input);
        });
      }
    }
  });

  $('#txtMultimedia').keyup(function () {
    createPreviewforImage($(this), window.location.pathname);
  });

  $("#btnFileSection").change(function () {
    chargePreviewforImage($('#preview_btnFileSection'), $(this));
  });

  $("#btnFilefront").change(function () {
    chargePreviewforImage($('#preview_btnFilefront'), $(this));
  });

  $("#btnFileback").change(function () {
    chargePreviewforImage($('#preview_btnFileback'), $(this));
  });

  $("input[name='txtNumberFront']").keyup(function () {
    let numberFieldsFront = $(this).val();
    rowContainerFieldsFront.empty();
    let counterFieldsFront = 1;
    while (counterFieldsFront <= numberFieldsFront) {
      let containerContentFront = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' });
      let labelContentFront = $('<label>', { 'class': 'form-label', html: 'Content fields:' });
      let inputContentFront = $('<textarea>', { id: "contentFront_" + counterFieldsFront, name: "contentFront_" + counterFieldsFront, 'class': 'form-control', style: 'height:38px', placeholder: 'Enter a content fields', maxLength: 500, required: true });
      let messageContentFront = $("<div>", { 'class': 'msg msg_' + inputContentFront.attr('id') });
      rowContainerFieldsFront.append(containerContentFront.append(labelContentFront, inputContentFront, messageContentFront));
      autosize(inputContentFront);
      counterFieldsFront++;
    }
  });

  $("input[name='txtNumberBack']").keyup(function () {
    let numberFieldsBack = $(this).val();
    rowContainerFieldsBack.empty();
    let counterFieldsBack = 1;
    while (counterFieldsBack <= numberFieldsBack) {
      let containerContentBack = $('<div>', { 'class': 'col-12 col-md-6 col-xl-6 mt-3' });
      let labelContentBack = $('<label>', { 'class': 'form-label', html: 'Content fields:' });
      let inputContentBack = $('<textarea>', { id: "contentBack_" + counterFieldsBack, name: "contentBack_" + counterFieldsBack, 'class': 'form-control', style: 'height:38px', placeholder: 'Enter a content fields', maxLength: 500, required: true });
      let messageContentBack = $("<div>", { 'class': 'msg msg_' + inputContentBack.attr('id') });
      rowContainerFieldsBack.append(containerContentBack.append(labelContentBack, inputContentBack, messageContentBack));
      autosize(inputContentBack);
      counterFieldsBack++;
    }
  });

  $("#txtNumber-size").keyup(function () {
    let numberSizeFields = $(this).val();
    rowContainerSize.empty();
    let counterSizeFields = 1;
    while (counterSizeFields <= numberSizeFields) {
      let containerDescriptionFields = $('<div>', { 'class': 'col-12 col-md-7 col-xl-7 mt-3' });
      let labelDescriptionFields = $('<label>', { 'class': 'form-label', html: 'Description:' });
      let inputDescriptionFields = $('<input>', { type: 'text', id: 'txtSize_' + counterSizeFields, name: 'txtSize_' + counterSizeFields, 'class': 'form-control', placeholder: 'Enter the description', maxLength: 50, required: true });
      let messageDescriptionFields = $("<div>", { 'class': 'msg msg_' + inputDescriptionFields.attr('id') });
      rowContainerSize.append(containerDescriptionFields.append(labelDescriptionFields, inputDescriptionFields, messageDescriptionFields));
      let containerPriceFields = $('<div>', { 'class': 'col-12 col-md-5 col-xl-5 mt-3' });
      let labelPriceFields = $('<label>', { 'class': 'form-label', html: 'Price (The price can be 0 if the item is free):' });
      let inputPriceFields = $('<input>', { type: 'text', id: 'txtPrice_' + counterSizeFields, name: 'txtPrice_' + counterSizeFields, 'class': 'form-control', placeholder: 'Enter the price', maxLength: 15, required: true });
      let messagePriceFields = $("<div>", { 'class': 'msg msg_' + inputPriceFields.attr('id') });
      rowContainerSize.append(containerPriceFields.append(labelPriceFields, inputPriceFields, messagePriceFields));
      counterSizeFields++;
    }
  });

  $("#btnFileBriefcase").change(function () {
    chargePreviewforImage($('#preview_btnFileBriefcase'), $(this));
  });

  $("#btnImage").change(function () {
    chargePreviewforImage($('#preview_btnImage'), $(this));
  });

  function validaForm() {
    let validateForm = true;
    let inputsForm = $('input[type="text"],input[type="email"],input[type=password],input[type="file"],textarea');
    inputsForm.each(function () {
      let messageError = ".msg_" + $(this).attr("id");
      switch (true) {
        case ["text", "email", "password"].includes($(this).attr("type")) && $(this).val() === "":
          $(this).addClass("invalid");
          $(messageError).html("The field is required");
          validateForm = false;
          break;
        case $(this).attr("type") === "file" && ($(this).attr("id").includes("btnImage") || $(this).attr("id").includes("btnFileSection") || $(this).attr("id").includes("btnFilefront") || $(this).attr("id").includes("btnFileback") || $(this).attr("id").includes("btnFileBriefcase")) && $(this).get(0).files.length === 0:
          $(this).addClass("invalid");
          $(messageError).html("The image is required");
          validateForm = false;
          break;
        case $(this).attr("type") === "file" && $(this).attr("id").includes("btnVideo") && $(this).get(0).files.length === 0:
          $(this).addClass("invalid");
          $(messageError).html("The video is required");
          validateForm = false;
          break;
        case $(this)[0].localName === "textarea" && ($(this).attr("id").includes("imageInstructions") || $(this).attr("id").includes("baseInstructions") || $(this).attr("id").includes("contentInstructions")) && $(this).val() === "":
          $(this).addClass("invalid");
          $(messageError).html("The instructions is required");
          validateForm = false;
          break;
        case $(this)[0].localName === "textarea" && $(this).attr("id") !== "txtDescription" && $(this).val() === "":
          $(this).addClass("invalid");
          $(messageError).html("The content is required");
          validateForm = false;
          break;
      }
      $(this).keyup(function () {
        $(this).removeClass("invalid");
        $(messageError).empty();
      });
    });
    return validateForm;
  }

  function message(icon, title, background) {
    const Toast = Swal.mixin({
      toast: true,
      position: "bottom",
      showConfirmButton: false,
      timer: 4000,
    });
    Toast.fire({
      icon: icon,
      iconColor: "#fff",
      title: title,
      background: background,
    });
  }

  $("#enviar").bind("submit", function () {
    if (validaForm()) {
      $.ajax({
        type: $(this).attr("method"),
        url: $(this).attr("action"),
        data: new FormData(this),
        contentType: false,
        processData: false,
        success: function (data) {
          if (data != "Successfully saved") {
            message("error", data, "#CC1E1E");
          } else {
            message("success", data, "#4CC522");
            $(".minis").empty();
            $('#quantity,#video,#link').remove();
            $("#row-sizes,#row-base,#row-content,#row-multimedia,#content-file").empty();
            $("#enviar")[0].reset();
            if (window.location.pathname.includes('Uploaddata')) {
              let div = $('<div>', { id: 'quantity', 'class': 'col-12 mt-3' });
              let label = $('<label>', { 'class': 'form-control-files btn btn-enviar mb-0', html: 'Upload' });
              let input = $('<input>', { style: 'display:none;', type: 'file', id: 'btnImage', name: 'btnImage', accept: 'image/jpeg, image/png, image/jpg' });
              let msg = $('<div>', { 'class': 'msg msg_btnImage' });
              let preview = $('<div>', { id: 'preview_' + input.attr('id'), 'class': 'img-thumbnail mt-3' });
              $(input).change(function () { 
                chargePreviewforImage(preview, input);
              });
              containerTypeMultimedia.after(div.append(label.append(input), msg, preview));
            } else {
              let div = $('<div>', { id: 'quantity', 'class': 'col-12 mt-3' });
              let label = $('<label>', { 'class': 'form - label', html: 'Quantity of multimedia:' });
              let input = $('<input>', { type: 'text', 'class': 'form-control', id: 'txtMultimedia', name: 'txtMultimedia', placeholder: 'Enter a number amount of media content', maxLength: 50, required: true });
              let msg = $('<div>', { 'class': 'msg msg_txtMultimedia' });
              $(input).keyup(function () {
                createPreviewforImage($(input));
              });
              containerTypeMultimedia.after(div.append(label, input, msg));
            }
            
          }
        }
      });
    }
    return false;
  });
});
