$(document).ready(function () {
  const previews = $('.minis');

  autosize($('textarea'));

  $('#SwitchPass').on("change", function () {
    if ($(this).prop('checked')) {
      $("#txtPassword").removeAttr("readonly");
    } else {
      $("#txtPassword").attr("readonly", "readonly");
    }
  });

  function video_preview(preview, btn) {
    preview.empty();
    let kilobyte = parseInt(btn.prop('files')[0].size) / 1024;
    if (btn.prop('files').length !== 0 && kilobyte < 5242880) {
      let reader = new FileReader();
      reader.readAsDataURL(btn.prop('files')[0]);
      reader.onload = function () {
        let video = $('<video>', { id: 'video-tag', controls: true, preload: 'metada' });
        let source = $('<source>', { id: 'video-source', src: reader.result });
        preview.append(video.append(source));
      };
      $(".msg_" + btn.attr('name')).removeClass("invalid");
      $(".msg_" + btn.attr('name')).empty();
    } else {
      message("error", "the video is too large (maximum 5GB)", "#CC1E1E");
      btn.val('');
    }
  }

  function cargar_preview(preview, btn) {
    preview.empty();
    let kilobyte = parseInt(btn.prop('files')[0].size) / 1024;
    if (btn.prop('files').length !== 0 && kilobyte < 2048) {
      let reader = new FileReader();
      reader.readAsDataURL(btn.prop('files')[0]);
      reader.onload = function () {
        let picture = $('<picture>');
        let image = $('<img>', { 'class': 'img-' + btn.attr('id'), src: reader.result, alt: btn.prop('files')[0].name });
        preview.append(picture.append(image));
      };
      $(".msg_" + btn.attr('name')).removeClass("invalid");
      $(".msg_" + btn.attr('name')).empty();
    } else {
      message("error", "the image is too large (maximum 2MB)", "#CC1E1E");
      btn.val('');
    }
  }

  $('#cboSection').change(function () {
    $('#cboSubsection').empty();
    $.ajax({
      type: 'POST',
      url: $('#ruta').val(),
      data: { cboSection: $(this).val() },
      success: function (data) {
        $('#cboSubsection').append(data);
      }
    });
  });

  $('#switchmls').on("change", function () {
    $('.switchmls').empty();
    if ($(this).prop('checked')) {
      $('.switchmls').text('Active');
    } else {
      $('.switchmls').text('Inactive');
    }
  });

  $("#btnFileSection").change(function () {
    cargar_preview($('#preview_btnFileSection'), $(this));
  });

  $("#btnFilefront").change(function () {
    cargar_preview($('#preview_btnFilefront'), $(this));
  });

  $("#btnFileback").change(function () {
    cargar_preview($('#preview_btnFileback'), $(this));
  });

  $('#txtLink').keyup(function () {
    $('#preview_txtLink').empty();
    let url;
    let regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    let match = $(this).val().match(regExp);
    if (match && match[2].length == 11) {
      url = 'https://www.youtube.com/embed/' + match[2];
      let video = $('<div>', { 'class': 'embed-responsive embed-responsive-16by9 mt-3' });
      let iframe = $('<iframe>', { class: 'embed-responsive-item', src: url, allowfullscreen: true });
      $('#preview_txtLink').append(video.append(iframe));
    }
  });

  $("#btnVideo").change(function () {
    video_preview($('#preview_btnVideo'), $(this));
  });

  $('.picture').each(function (i) {
    $(this).change(function () {
      cargar_preview($(previews[i]), $(this));
    });
  });

  $("#btnFileBriefcase").change(function () {
    cargar_preview($('#preview_btnFileBriefcase'), $(this));
  });

  function validaForm() {
    let bool = true;
    let inputs = $('input[type="text"],input[type="email"],input[type=password],input[type="file"],textarea');
    inputs.each(function () {
      let mensaje = ".msg_" + $(this).attr("id");
      switch (true) {
        case ["text", "email", "password"].includes($(this).attr("type")) && $(this).val() === "":
          $(this).addClass("invalid");
          $(mensaje).html("The field is required");
          bool = false;
          break;
        case $(this)[0].localName === "textarea" && ($(this).attr("id").includes("imageInstructions") || $(this).attr("id").includes("baseInstructions") || $(this).attr("id").includes("contentInstructions")) && $(this).val() === "":
          $(this).addClass("invalid");
          $(mensaje).html("The instructions is required");
          bool = false;
          break;
        case $(this)[0].localName === "textarea" && $(this).attr("id") !== "txtDescription" && $(this).val() === "":
          $(this).addClass("invalid");
          $(mensaje).html("The content is required");
          bool = false;
          break;
      }
      $(this).keyup(function () {
        $(this).removeClass("invalid");
        $(mensaje).empty();
      });
    });
    return bool;
  }

  function message(icon, title, background) {
    const Toast = Swal.mixin({
      toast: true,
      position: "bottom",
      showConfirmButton: false,
      timer: 4000,
    });
    Toast.fire({
      icon: icon,
      iconColor: "#fff",
      title: title,
      background: background,
    });
  }

  $("#enviar").bind("submit", function () {
    if (validaForm()) {
      $.ajax({
        type: $(this).attr("method"),
        url: $(this).attr("action"),
        data: new FormData(this),
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (data) {
          if (data[1] != "Successfully Updated") {
            message("error", data[1], "#CC1E1E");
          } else {
            message("success", data[1], "#4CC522");
            setTimeout(() => {
              window.location.href =
                data[0]
            }, 1500);
          }
        },
      });
    }
    return false;
  });
});
