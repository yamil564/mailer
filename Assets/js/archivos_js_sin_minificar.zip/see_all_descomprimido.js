$(document).ready(function () {

  function message(icon, title, background) {
    const Toast = Swal.mixin({
      toast: true,
      position: "bottom",
      showConfirmButton: false,
      timer: 4000,
    });
    Toast.fire({
      icon: icon,
      iconColor: "#fff",
      title: title,
      background: background,
    });
  }

  $(".delete").on('click', function () {
    $("#btnDelete").val($(this).val());
  });

  $("#btnDelete").click(function () {
    $.ajax({
      type: "POST",
      url: $("input[type='hidden']").val(),
      data: { btnDelete: $(this).val() },
      success: function (data) {
        if (data === "Successfully removed") {
          message("success", data, "#4CC522");
          setTimeout(() => {
            location.reload();
          }, 1500);
        } else {
          message("error", data, "#CC1E1E");
        }
      },
    });
  });
});